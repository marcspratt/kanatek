=== TCSN-Shortcodes ===
Contributors: Tansh
Donate link: http://themeforest.net/user/tansh  
Tags: Shortcodes, Button, Tabs, Accordion, Icons, Lists, Text color, Dropcap, Highlight, Heading styles, Feature styles, Person, Box, Divider, Block quote, Alert, Progress bars, Tooltip, Carousel, Lightbox, Video, Table, Pricing Table
Requires at least: 3.6
Tested up to: 3.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Creates Shortcodes.

== Description ==

Creates Shortcodes.

== Installation ==

1. Upload `TCSN-Shortcodes` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Changelog ==

= 2.0.1 =
* Glyphicons removed removed from tinymce / kept in shortcodes for backward compatibility

= 2.0.0 =
* Made changes for WP 3.9 Compatibility

= 1.1.0 =
* Removed following shortcodes from plugin, so as to make it go with visual composer.

- Row
- Columns
- Tabs
- Accordion
- Alert
- Progress bars
- Video
- Image without lightbox


= 1.0.0 =
* Initial release.
